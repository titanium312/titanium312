import logo from './logo.svg';
import "./App.css";
import Movil_Div from './Componentes/Movil-Div/Movil_Div';
import Cabecera from './Componentes/Cabezera/Cabecera';
import Formulario from './Componentes/Formulario/Formulario';
import Up_Secciones from './Componentes/UP-Secciones/Up-secciones';

function App() {
  return (
    <div id="body">

<Formulario/>
   {/*<Cabecera/>
    <div id="Header">
      <div id="Movil"><Movil_Div/></div>
      <div id="div-Formula"><Formulario/></div>
    </div>
    <Up_Secciones/>
   */}
</div>
  );
}




export default App;
