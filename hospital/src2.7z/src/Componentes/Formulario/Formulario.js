import React, { useState } from 'react';
import './estilos.css'; 

const Formulario = () => {
    const [tipoDocumento, setTipoDocumento] = useState('');
    const [numeroDocumento, setNumeroDocumento] = useState('');
    const [numeroCelular, setNumeroCelular] = useState('');
    const [direccion, setDireccion] = useState('');

    const Presiona = (e) => {
        e.preventDefault();
        console.log({
            tipoDocumento,
            numeroDocumento,
            numeroCelular,
            direccion,
        });
    };

    return (
        <form onSubmit={Presiona} className="formulario">
            <h2>Formulario de Registro</h2>

            <label htmlFor="tipo-documento">Tipo de Documento:</label>
            <select
                id="tipo-documento"
                value={tipoDocumento}
                onChange={(e) => setTipoDocumento(e.target.value)}
                required
            >
                <option value="" disabled>
                    Selecciona un tipo de documento
                </option>
                <option value="cedula">Cédula</option>
                <option value="tarjeta_identidad">Tarjeta de Identidad</option>
                <option value="registro_civil">Registro Civil</option>
            </select>

            <label htmlFor="numero-documento">Número de Documento:</label>
            <input
                type="text"
                id="numero-documento"
                value={numeroDocumento}
                onChange={(e) => setNumeroDocumento(e.target.value)}
                required
            />

            <label htmlFor="numero-celular">Número Celular:</label>
            <input
                type="tel"
                id="numero-celular"
                value={numeroCelular}
                onChange={(e) => setNumeroCelular(e.target.value)}
                required
            />

            <label htmlFor="direccion">Dirección:</label>
            <input
                type="text"
                id="direccion"
                value={direccion}
                onChange={(e) => setDireccion(e.target.value)}
                required
            />

            <button type="submit">Enviar</button>
        </form>
    );
};

export default Formulario;
